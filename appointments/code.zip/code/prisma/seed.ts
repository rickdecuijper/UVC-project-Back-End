import { PrismaClient } from '@prisma/client';
const prisma: PrismaClient = new PrismaClient();
import { loadTimeSlots } from './seeders/timeslot_seeder.ts';

const load = async (): Promise<void> => {
  try {
    await loadTimeSlots();
  } catch (e) {
    console.error(e);
    process.exit(1);
  } finally {
    await prisma.$disconnect();
  }
};

load();
