import { PrismaClient } from '@prisma/client';
const prisma: PrismaClient = new PrismaClient();
import { Task } from '../types.ts';

const tasks: Task[] = [
    {
        title: 'Plein Vegen',
        beschrijving: 'Alle bladeren moeten van het plein af geveegd worden',
        status: 'Nog niet voltooid',
        timeslotId: 1,
        child_id: 1
    }
]
